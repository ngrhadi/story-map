import headquarters from "./headquarters-star-32px.png";

export default {
	headquarters,
};
