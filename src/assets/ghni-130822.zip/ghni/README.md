## MAPBOX GL JS

Handle click event popup and event open new windows on country polygon

---

for event popup on index.html

for event open new windows on index-v2.html

---
